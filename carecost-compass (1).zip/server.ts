import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // JSON body parser with 15MB limit for high-res photo uploads (never stored to disk)
  app.use(express.json({ limit: '15mb' }));

  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({
    apiKey: apiKey || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  /**
   * POST /api/extract-prescription
   * Extracts brand, active_ingredient, strength, doses_per_day, duration_days
   * Supports photo (base64) or text.
   * Safety: In-memory only, no disk writes, no medical advice.
   */
  app.post('/api/extract-prescription', async (req, res) => {
    try {
      const { imageBase64, mimeType, text } = req.body;

      if (!imageBase64 && (!text || !text.trim())) {
        return res.status(400).json({
          error: 'Please provide either a prescription photo or written medicine details.',
        });
      }

      if (!apiKey) {
        return res.status(500).json({
          error: 'GEMINI_API_KEY is not configured on the server. Please check environment settings.',
        });
      }

      const systemInstruction = `You are an expert clinical transcription assistant.
Your task is to transcribe prescription labels or typed medication instructions into structured JSON data.

CRITICAL RULES:
1. Extract each medication into the array.
2. For each medication:
   - "brand": Brand/trade name as written (e.g. "Lipitor", "Glucophage", "Norvasc"), or generic name if no brand is specified.
   - "active_ingredient": The active chemical/generic compound name in all LOWERCASE (e.g. "atorvastatin", "metformin", "amlodipine", "omeprazole", "losartan", "sertraline", "amoxicillin", "levothyroxine", "cetirizine", "lisinopril"). Do not include dosages or salt names here.
   - "strength": Exact strength unit as written (e.g. "20mg", "500mg", "5mg", "50mcg").
   - "doses_per_day": Integer count of how many doses/pills/capsules taken per day. If "once daily" or "QD" -> 1. If "twice daily" or "BID" -> 2. If "three times daily" or "TID" -> 3. Default to 1 if unspecified.
   - "duration_days": Number of days prescribed (e.g., 7 for antibiotics, 14, 30). Set to null if it is ongoing/chronic maintenance medication (e.g., cholesterol, hypertension, diabetes pills).
3. SAFETY RULE: Never give dosing advice, never change doses, never advise stopping or switching drugs. Transcribe ONLY what is visible or typed.
4. If the image is unreadable, blurry, completely dark, or does not contain a prescription, return an empty array.`;

      let contents: any[] = [];

      if (imageBase64) {
        contents = [
          {
            parts: [
              {
                inlineData: {
                  mimeType: mimeType || 'image/jpeg',
                  data: imageBase64,
                },
              },
              {
                text: 'Extract all medications from this prescription label or document into the requested JSON schema.',
              },
            ],
          },
        ];
      } else {
        contents = [
          {
            parts: [
              {
                text: `Extract all medications from this written prescription description into the requested JSON schema:\n\n${text}`,
              },
            ],
          },
        ];
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.1,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            description: 'List of extracted medications',
            items: {
              type: Type.OBJECT,
              properties: {
                brand: {
                  type: Type.STRING,
                  description: 'The trade or brand name on prescription',
                },
                active_ingredient: {
                  type: Type.STRING,
                  description: 'Active pharmaceutical ingredient in lowercase',
                },
                strength: {
                  type: Type.STRING,
                  description: 'Strength dosage with unit (e.g. 500mg)',
                },
                doses_per_day: {
                  type: Type.INTEGER,
                  description: 'Pills or doses taken per day',
                },
                duration_days: {
                  type: Type.INTEGER,
                  nullable: true,
                  description: 'Number of days prescribed, or null if ongoing maintenance',
                },
              },
              required: ['brand', 'active_ingredient', 'strength', 'doses_per_day'],
            },
          },
        },
      });

      const responseText = response.text || '[]';
      let parsedMedicines = [];
      try {
        parsedMedicines = JSON.parse(responseText);
      } catch (e) {
        console.error('Failed to parse Gemini output:', responseText);
        return res.status(422).json({
          error: 'Could not read structured prescription items. Please try with a clearer photo or enter details manually.',
        });
      }

      if (!Array.isArray(parsedMedicines) || parsedMedicines.length === 0) {
        return res.status(422).json({
          error: 'No recognizable medications could be identified. Please make sure the photo is sharp and well-lit, or type medicine names.',
        });
      }

      // Sanitize fields
      const cleaned = parsedMedicines.map((m: any, idx: number) => ({
        id: `extracted-${idx}-${Date.now()}`,
        brand: String(m.brand || '').trim(),
        active_ingredient: String(m.active_ingredient || '').toLowerCase().trim(),
        strength: String(m.strength || '').trim(),
        doses_per_day: Number(m.doses_per_day) || 1,
        duration_days: typeof m.duration_days === 'number' && m.duration_days > 0 ? Math.round(m.duration_days) : null,
      }));

      return res.json({ medicines: cleaned });
    } catch (error: any) {
      console.error('Error in /api/extract-prescription:', error);
      return res.status(500).json({
        error: error.message || 'An error occurred while analyzing the prescription.',
      });
    }
  });

  /**
   * POST /api/consultation-summary
   * Plain-language summary under 120 words + 3 practical questions for the pharmacist.
   * Strictly adheres to safety notice requirements.
   */
  app.post('/api/consultation-summary', async (req, res) => {
    try {
      const { medications, totalCost, possibleSavings, householdIncome, burdenPercent } = req.body;

      if (!medications || !Array.isArray(medications) || medications.length === 0) {
        return res.status(400).json({ error: 'No medication details provided.' });
      }

      const promptData = {
        medications: medications.map((m: any) => ({
          brand: m.brand,
          active_ingredient: m.active_ingredient,
          strength: m.strength,
          daysCalculated: m.daysCalculated,
          currentCost: m.currentTotalCost,
          lowestOption: m.lowestProductMatched,
          lowestCost: m.lowestTotalCost,
          savings: m.possibleSavings,
          matched: m.matched,
        })),
        totalCost,
        possibleSavings,
        householdIncome: householdIncome || null,
        burdenPercent: burdenPercent || null,
      };

      const systemInstruction = `You are a compassionate, clear patient advocacy assistant for CareCost Compass.
Your audience is a family paying out-of-pocket for their medications.

MANDATORY RULES:
1. Provide a plain-language summary in UNDER 120 WORDS. Explain in warm, straightforward language what these medicines generally help with and how bioequivalent generics can lower out-of-pocket costs while containing the identical active ingredient.
2. Provide exactly 3 specific, practical questions the patient can ask their pharmacist at the pharmacy counter.
3. ABSOLUTE SAFETY RULES:
   - NEVER give dosing instructions or suggest changing pill counts.
   - NEVER tell the user to switch or stop a medicine.
   - ALWAYS state that only a licensed pharmacist or doctor must confirm any generic alternative or medication change.
4. Output strict JSON with:
   - "summary": string (plain language, under 120 words)
   - "pharmacist_questions": array of exactly 3 strings (actionable questions for pharmacist)
   - "safety_notice": string (a reassuring reminder that pharmacist/physician must verify substitution)`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          {
            parts: [
              {
                text: `Analyze this prescription financial breakdown and generate a plain-language summary under 120 words and 3 pharmacist questions:\n\n${JSON.stringify(promptData, null, 2)}`,
              },
            ],
          },
        ],
        config: {
          systemInstruction,
          temperature: 0.2,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: {
                type: Type.STRING,
                description: 'Plain language summary under 120 words',
              },
              pharmacist_questions: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '3 practical questions for the pharmacist',
              },
              safety_notice: {
                type: Type.STRING,
                description: 'Safety reminder that a doctor or pharmacist must confirm changes',
              },
            },
            required: ['summary', 'pharmacist_questions', 'safety_notice'],
          },
        },
      });

      const responseText = response.text || '{}';
      const parsed = JSON.parse(responseText);

      return res.json(parsed);
    } catch (error: any) {
      console.error('Error in /api/consultation-summary:', error);
      // Safe fallback response if API fails
      return res.json({
        summary:
          'Your prescription includes essential daily medications. Bioequivalent generics contain the exact same active ingredients as brand names, often at a fraction of the out-of-pocket cost.',
        pharmacist_questions: [
          'Are any of these prescribed medications eligible for FDA-approved generic substitution at your counter?',
          'Would filling a 90-day supply or using a pharmacy discount plan offer additional savings?',
          'Does this generic alternative need to be taken with food or at a different time of day?',
        ],
        safety_notice:
          'A licensed pharmacist or doctor must confirm any medication change, dosage, or generic substitution before you make any adjustments.',
      });
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CareCost Compass server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
