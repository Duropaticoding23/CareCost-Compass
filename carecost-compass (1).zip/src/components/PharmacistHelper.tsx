import React, { useState } from 'react';
import { MessageSquare, HelpCircle, Copy, Check, ShieldCheck, Stethoscope } from 'lucide-react';

interface PharmacistHelperProps {
  summary: string | null;
  questions: string[];
  safetyNotice?: string;
  isLoading: boolean;
}

export const PharmacistHelper: React.FC<PharmacistHelperProps> = ({
  summary,
  questions,
  safetyNotice,
  isLoading,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!summary && questions.length === 0) return;
    const textToCopy = `CareCost Compass - Pharmacist Consultation Notes:\n\nSummary:\n${summary || ''}\n\nQuestions to ask your pharmacist:\n${questions.map((q, i) => `${i + 1}. ${q}`).join('\n')}\n\nNotice: ${safetyNotice || 'A pharmacist or doctor must confirm any change.'}`;

    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  return (
    <div className="bg-emerald-900 text-white rounded-3xl p-4 sm:p-6 md:p-7 shadow-xs mb-8 overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-800 text-emerald-200 flex items-center justify-center shrink-0">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight text-white">
              Pharmacist Consultation Helper
            </h2>
            <p className="text-xs md:text-sm text-emerald-200/80">
              Plain-language overview & questions for the pharmacy counter
            </p>
          </div>
        </div>

        {summary && !isLoading && (
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-800 hover:bg-emerald-700 text-white rounded-xl transition-colors self-start sm:self-auto min-h-[44px]"
            title="Copy questions to clipboard"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-300" />
                <span>Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-emerald-300" />
                <span>Copy for Pharmacy Visit</span>
              </>
            )}
          </button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-4 py-4">
          <div className="flex items-center gap-2 text-emerald-200 text-sm animate-pulse">
            <div className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
            <span>Consulting Gemini for plain-language summary & questions...</span>
          </div>
          <div className="h-16 bg-emerald-800/60 rounded-2xl animate-pulse" />
          <div className="h-24 bg-emerald-800/40 rounded-2xl animate-pulse" />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Summary paragraph (Under 120 words) */}
          <div className="bg-emerald-850 bg-emerald-950/40 border border-emerald-700/50 rounded-2xl p-4 md:p-5">
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-emerald-300 mb-2">
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span>Plain-Language Summary (Under 120 Words)</span>
            </div>
            <p className="text-sm md:text-base leading-relaxed text-emerald-50">
              {summary ||
                'This prescription includes daily maintenance therapies. Bioequivalent generic options contain the exact identical active ingredient, strength, and therapeutic effect at a fraction of brand-name costs.'}
            </p>
          </div>

          {/* 3 Questions to ask the pharmacist */}
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-emerald-300 mb-3">
              <HelpCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>3 Questions To Ask Your Pharmacist</span>
            </div>

            <ol className="space-y-2.5">
              {questions.length > 0 ? (
                questions.map((q, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-3 p-3.5 rounded-xl bg-emerald-800/50 border border-emerald-700/40 text-sm text-emerald-50"
                  >
                    <span className="w-6 h-6 rounded-lg bg-emerald-700 text-emerald-200 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-snug">{q}</span>
                  </li>
                ))
              ) : (
                <li className="text-sm text-emerald-200">
                  Questions will appear once your prescription is analyzed.
                </li>
              )}
            </ol>
          </div>

          {/* Pharmacist confirmation notice */}
          <div className="p-3.5 bg-emerald-950/70 border border-emerald-600/40 rounded-xl text-xs text-emerald-200 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong>Professional Verification Reminder:</strong>{' '}
              {safetyNotice ||
                'A licensed pharmacist or doctor must confirm any generic alternative, verify insurance coverage or cash discount cards, and authorize substitution before you change your medications.'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
