import React, { useState, useRef } from 'react';
import { Camera, Upload, Type, DollarSign, Sparkles, AlertCircle, FileText, X, Check } from 'lucide-react';
import { ExtractedMedicine } from '../utils/pricingEngine';
import { resizeImageToMax1280 } from '../utils/imageResizer';

interface PrescriptionInputProps {
  onExtractedFromPhoto: (base64: string, mimeType: string, income: number) => Promise<void>;
  onExtractedFromText: (text: string, income: number) => Promise<void>;
  onLoadPreset: (items: ExtractedMedicine[], income: number) => void;
  isLoading: boolean;
  income: number;
  onIncomeChange: (val: number) => void;
}

export const PrescriptionInput: React.FC<PrescriptionInputProps> = ({
  onExtractedFromPhoto,
  onExtractedFromText,
  onLoadPreset,
  isLoading,
  income,
  onIncomeChange,
}) => {
  const [activeTab, setActiveTab] = useState<'photo' | 'text'>('photo');
  const [typedText, setTypedText] = useState('');
  const [isResizing, setIsResizing] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    sizeKb: number;
    base64: string;
    mimeType: string;
    previewUrl: string;
    wasResized: boolean;
    dimensions: string;
  } | null>(null);
  const [inputError, setInputError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Resize image to max 1280px on the longest side before processing/sending
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setInputError('Please select a valid photo file (PNG, JPG, or WebP).');
      return;
    }

    try {
      setIsResizing(true);
      const resized = await resizeImageToMax1280(file);

      setSelectedFile({
        name: file.name,
        sizeKb: resized.sizeKb,
        base64: resized.base64,
        mimeType: resized.mimeType,
        previewUrl: `data:${resized.mimeType};base64,${resized.base64}`,
        wasResized: resized.wasResized,
        dimensions: `${resized.width}×${resized.height}`,
      });
    } catch (err: any) {
      setInputError('Could not process this image file. Please try another photo.');
    } finally {
      setIsResizing(false);
    }
  };

  const handleClearFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setInputError(null);

    if (activeTab === 'photo') {
      if (!selectedFile) {
        setInputError('Please take or upload a photo of your prescription or medication label.');
        return;
      }
      await onExtractedFromPhoto(selectedFile.base64, selectedFile.mimeType, income);
    } else {
      if (!typedText.trim()) {
        setInputError('Please enter medicine names and strengths (e.g. Lipitor 20mg once a day).');
        return;
      }
      await onExtractedFromText(typedText, income);
    }
  };

  // Illustrative presets for quick evaluation
  const presets = [
    {
      title: 'Chronic Heart & Diabetes',
      income: 1800,
      description: 'Glucophage 500mg, Lipitor 20mg, Norvasc 5mg',
      items: [
        {
          brand: 'Glucophage',
          active_ingredient: 'metformin',
          strength: '500mg',
          doses_per_day: 2,
          duration_days: null,
        },
        {
          brand: 'Lipitor',
          active_ingredient: 'atorvastatin',
          strength: '20mg',
          doses_per_day: 1,
          duration_days: null,
        },
        {
          brand: 'Norvasc',
          active_ingredient: 'amlodipine',
          strength: '5mg',
          doses_per_day: 1,
          duration_days: null,
        },
      ],
    },
    {
      title: 'Acute Infection & Allergy',
      income: 2200,
      description: 'Amoxil 500mg (7-day course), Zyrtec 10mg (30-day)',
      items: [
        {
          brand: 'Amoxil',
          active_ingredient: 'amoxicillin',
          strength: '500mg',
          doses_per_day: 3,
          duration_days: 7,
        },
        {
          brand: 'Zyrtec',
          active_ingredient: 'cetirizine',
          strength: '10mg',
          doses_per_day: 1,
          duration_days: null,
        },
      ],
    },
    {
      title: 'Family Multi-Med Care',
      income: 1500, // Demonstrates >10% catastrophic burden
      description: 'Zoloft 50mg, Cozaar 50mg, Prilosec 20mg, Glucophage 500mg',
      items: [
        {
          brand: 'Zoloft',
          active_ingredient: 'sertraline',
          strength: '50mg',
          doses_per_day: 1,
          duration_days: null,
        },
        {
          brand: 'Cozaar',
          active_ingredient: 'losartan',
          strength: '50mg',
          doses_per_day: 1,
          duration_days: null,
        },
        {
          brand: 'Prilosec',
          active_ingredient: 'omeprazole',
          strength: '20mg',
          doses_per_day: 1,
          duration_days: null,
        },
        {
          brand: 'Glucophage',
          active_ingredient: 'metformin',
          strength: '500mg',
          doses_per_day: 2,
          duration_days: null,
        },
      ],
    },
  ];

  return (
    <div className="bg-white rounded-3xl p-4 sm:p-6 md:p-7 shadow-xs border border-emerald-950/10 mb-8 overflow-hidden">
      <div className="mb-5">
        <span className="text-xs uppercase tracking-wider font-bold text-emerald-800 block mb-1">
          Step 1: Input Prescription
        </span>
        <h2 className="text-xl md:text-2xl font-bold text-emerald-950 tracking-tight">
          Read Prescription Details
        </h2>
        <p className="text-xs sm:text-sm text-stone-600 mt-1">
          Snap a bottle or script photo (automatically scaled to 1280px for instant OCR) or type your medicines.
        </p>
      </div>

      {inputError && (
        <div className="mb-5 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-rose-900 text-xs sm:text-sm flex items-start gap-2.5">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1">{inputError}</div>
        </div>
      )}

      {/* Segmented input mode selector (360px optimized) */}
      <div className="flex p-1 bg-stone-100 rounded-2xl mb-5">
        <button
          type="button"
          onClick={() => {
            setActiveTab('photo');
            setInputError(null);
          }}
          className={`flex-1 py-2.5 px-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 min-h-[44px] whitespace-nowrap ${
            activeTab === 'photo'
              ? 'bg-white text-emerald-900 shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Camera className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="truncate">Photo Upload</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveTab('text');
            setInputError(null);
          }}
          className={`flex-1 py-2.5 px-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 min-h-[44px] whitespace-nowrap ${
            activeTab === 'text'
              ? 'bg-white text-emerald-900 shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Type className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="truncate">Type Text</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
        {activeTab === 'photo' ? (
          <div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              capture="environment"
              className="hidden"
              id="prescription-file-upload"
            />

            {!selectedFile ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-emerald-300 hover:border-emerald-600 hover:bg-emerald-50/50 transition-colors rounded-2xl p-5 sm:p-7 text-center cursor-pointer bg-emerald-50/20 group"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 mx-auto rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="font-semibold text-emerald-950 text-sm sm:text-base mb-1">
                  Tap to snap a photo or choose an image
                </p>
                <p className="text-[11px] sm:text-xs text-stone-500 max-w-sm mx-auto leading-relaxed">
                  Automatically resizes large camera photos to 1280px before sending. Images are in-memory only and never saved.
                </p>
                {isResizing && (
                  <div className="mt-2 text-xs font-semibold text-emerald-800 flex items-center justify-center gap-1.5">
                    <div className="w-3.5 h-3.5 border-2 border-emerald-700 border-t-transparent rounded-full animate-spin" />
                    <span>Optimizing image resolution...</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="relative border border-emerald-300 rounded-2xl p-3.5 sm:p-4 bg-emerald-50/40 flex items-center gap-3">
                <img
                  src={selectedFile.previewUrl}
                  alt="Prescription preview"
                  className="w-14 h-14 sm:w-16 sm:h-16 object-cover rounded-xl border border-emerald-200 shrink-0"
                />
                <div className="flex-1 min-w-0 text-left">
                  <p className="font-semibold text-emerald-950 text-xs sm:text-sm truncate">
                    {selectedFile.name}
                  </p>
                  <p className="text-[11px] text-stone-600 mt-0.5">
                    {selectedFile.dimensions} · {selectedFile.sizeKb} KB
                  </p>
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded-md mt-1">
                    <Check className="w-3 h-3 text-emerald-700" />
                    <span>Ready at 1280px max</span>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleClearFile}
                  className="p-2 text-stone-400 hover:text-stone-700 hover:bg-white rounded-xl transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center shrink-0"
                  title="Remove selected photo"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
        ) : (
          <div>
            <label
              htmlFor="prescription-text-input"
              className="block text-xs sm:text-sm font-semibold text-stone-800 mb-1"
            >
              Prescription Description
            </label>
            <textarea
              id="prescription-text-input"
              rows={3}
              value={typedText}
              onChange={(e) => setTypedText(e.target.value)}
              placeholder="e.g. Lipitor 20mg once daily ongoing, Glucophage 500mg twice daily, Amoxil 500mg 3 times daily for 7 days"
              className="w-full p-3 text-sm sm:text-base rounded-2xl border border-stone-200 focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 outline-none transition-all resize-none bg-stone-50/50"
            />
            <p className="text-[11px] text-stone-500 mt-1">
              Specify brand/generic name, strength (e.g. 500mg), doses per day, and duration if short-term.
            </p>
          </div>
        )}

        {/* Household Income Section */}
        <div className="pt-2 border-t border-stone-100">
          <label
            htmlFor="household-income-input"
            className="flex items-center justify-between text-xs sm:text-sm font-semibold text-stone-800 mb-1"
          >
            <span className="flex items-center gap-1 truncate">
              <DollarSign className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span>Monthly Household Income</span>
            </span>
            <span className="text-[10px] text-stone-500 font-normal shrink-0">
              For 10% burden analysis
            </span>
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400 font-medium text-sm">
              $
            </span>
            <input
              id="household-income-input"
              type="number"
              min="0"
              step="50"
              value={income > 0 ? income : ''}
              onChange={(e) => onIncomeChange(Number(e.target.value) || 0)}
              placeholder="e.g. 2000"
              className="w-full pl-7 pr-3 py-2.5 text-sm sm:text-base rounded-2xl border border-stone-200 focus:border-emerald-700 focus:ring-1 focus:ring-emerald-700 outline-none transition-all tabular-nums bg-stone-50/50 min-h-[44px]"
            />
          </div>
        </div>

        {/* Primary Action Button */}
        <button
          type="submit"
          disabled={isLoading || isResizing}
          className="w-full py-3.5 px-4 bg-emerald-800 hover:bg-emerald-900 active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed text-white font-bold text-sm sm:text-base rounded-2xl shadow-sm transition-all flex items-center justify-center gap-2 min-h-[48px]"
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Extracting Medicines with Gemini...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-emerald-200 shrink-0" />
              <span className="truncate">Read Prescription Details</span>
            </>
          )}
        </button>
      </form>

      {/* Preset Buttons for Quick Testing */}
      <div className="mt-5 pt-4 border-t border-stone-100">
        <div className="flex items-center gap-1.5 text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-2">
          <FileText className="w-3 h-3 text-emerald-700 shrink-0" />
          <span>Quick Sample Prescriptions:</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {presets.map((preset, i) => (
            <button
              key={i}
              type="button"
              disabled={isLoading}
              onClick={() => onLoadPreset(preset.items, preset.income)}
              className="p-2.5 sm:p-3 text-left rounded-xl border border-emerald-200/80 bg-emerald-50/40 hover:bg-emerald-100/70 hover:border-emerald-400 transition-colors group min-h-[44px]"
            >
              <div className="text-xs font-bold text-emerald-950 group-hover:text-emerald-900 flex items-center justify-between gap-1">
                <span className="truncate">{preset.title}</span>
                <span className="text-[10px] text-emerald-700 bg-white px-1.5 py-0.5 rounded font-mono shrink-0">
                  ${preset.income}/mo
                </span>
              </div>
              <div className="text-[10px] text-stone-600 mt-0.5 line-clamp-1">
                {preset.description}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
