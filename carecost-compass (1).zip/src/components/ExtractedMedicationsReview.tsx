import React from 'react';
import { CheckCircle, Plus, Trash2, AlertCircle, ArrowRight, RotateCcw, Lightbulb } from 'lucide-react';
import { ExtractedMedicine } from '../utils/pricingEngine';
import { PRICE_DATABASE } from '../data/priceDatabase';

interface ExtractedMedicationsReviewProps {
  medicines: ExtractedMedicine[];
  onUpdateMedicine: (index: number, updated: ExtractedMedicine) => void;
  onAddMedicine: () => void;
  onRemoveMedicine: (index: number) => void;
  onConfirmAndCalculate: () => void;
  onReset: () => void;
  isCalculating: boolean;
}

export const ExtractedMedicationsReview: React.FC<ExtractedMedicationsReviewProps> = ({
  medicines,
  onUpdateMedicine,
  onAddMedicine,
  onRemoveMedicine,
  onConfirmAndCalculate,
  onReset,
  isCalculating,
}) => {
  // Get unique catalog active ingredients for quick correction helpers
  const catalogSuggestions = React.useMemo(() => {
    const map = new Map<string, string[]>();
    PRICE_DATABASE.forEach((item) => {
      const ing = item.active_ingredient.toLowerCase();
      if (!map.has(ing)) {
        map.set(ing, []);
      }
      if (!map.get(ing)?.includes(item.strength)) {
        map.get(ing)?.push(item.strength);
      }
    });
    return Array.from(map.entries()).map(([ingredient, strengths]) => ({
      ingredient,
      strengths,
    }));
  }, []);

  return (
    <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-xs border border-emerald-950/10 mb-8 overflow-hidden">
      {/* Step Header */}
      <div className="mb-4">
        <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider font-bold text-emerald-800 mb-1">
          <CheckCircle className="w-4 h-4 text-emerald-700" />
          <span>Step 2: Review Extracted Medications</span>
        </div>
        <h2 className="text-lg sm:text-xl font-bold text-emerald-950 tracking-tight">
          Verify Medicine Details Before Calculating
        </h2>
        <p className="text-xs sm:text-sm text-stone-600 mt-1">
          Check the transcribed medicines below. You can correct any OCR misreadings, adjust strengths, or add more medicines before running price calculations.
        </p>
      </div>

      {medicines.length === 0 ? (
        <div className="p-6 text-center border-2 border-dashed border-stone-200 rounded-2xl">
          <AlertCircle className="w-8 h-8 text-stone-400 mx-auto mb-2" />
          <p className="text-sm font-semibold text-stone-700">No medications listed yet.</p>
          <button
            type="button"
            onClick={onAddMedicine}
            className="mt-3 px-4 py-2 bg-emerald-800 text-white rounded-xl text-xs font-semibold min-h-[44px]"
          >
            + Add Medicine Manually
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {medicines.map((med, idx) => {
            const hasCatalogMatch = catalogSuggestions.some(
              (c) => c.ingredient === med.active_ingredient.toLowerCase().trim()
            );

            return (
              <div
                key={med.id || `med-review-${idx}`}
                className="p-3.5 sm:p-4 rounded-2xl border border-stone-200 bg-stone-50/60 hover:border-emerald-300 transition-colors space-y-3"
              >
                <div className="flex items-center justify-between gap-2 border-b border-stone-200/60 pb-2">
                  <span className="text-xs font-bold text-stone-500 uppercase tracking-wide">
                    Medication #{idx + 1}
                  </span>
                  <button
                    type="button"
                    onClick={() => onRemoveMedicine(idx)}
                    className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title="Remove this medicine"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* 360px-friendly stacked inputs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Brand Name */}
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 uppercase mb-1">
                      Brand / Label Name
                    </label>
                    <input
                      type="text"
                      value={med.brand}
                      onChange={(e) =>
                        onUpdateMedicine(idx, { ...med, brand: e.target.value })
                      }
                      placeholder="e.g. Lipitor, Glucophage"
                      className="w-full px-3 py-2 text-sm rounded-xl border border-stone-300 focus:border-emerald-700 outline-none bg-white min-h-[40px]"
                    />
                  </div>

                  {/* Active Ingredient (lowercase generic) */}
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 uppercase mb-1">
                      Active Ingredient (Generic)
                    </label>
                    <input
                      type="text"
                      value={med.active_ingredient}
                      onChange={(e) =>
                        onUpdateMedicine(idx, {
                          ...med,
                          active_ingredient: e.target.value.toLowerCase(),
                        })
                      }
                      placeholder="e.g. atorvastatin, metformin"
                      className="w-full px-3 py-2 text-sm font-mono rounded-xl border border-stone-300 focus:border-emerald-700 outline-none bg-white min-h-[40px]"
                    />
                  </div>
                </div>

                {/* Quick Catalog Ingredient Picker if not recognized or to fix typo */}
                {!hasCatalogMatch && (
                  <div className="p-2.5 bg-amber-50/80 border border-amber-200/80 rounded-xl text-xs">
                    <div className="flex items-center gap-1.5 text-amber-900 font-semibold mb-1.5">
                      <Lightbulb className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                      <span>Did you mean one of these catalog active ingredients?</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {catalogSuggestions.slice(0, 5).map((item) => (
                        <button
                          key={item.ingredient}
                          type="button"
                          onClick={() => {
                            onUpdateMedicine(idx, {
                              ...med,
                              active_ingredient: item.ingredient,
                              strength: item.strengths[0] || med.strength,
                            });
                          }}
                          className="px-2 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-900 border border-stone-200 rounded-lg text-[11px] font-medium text-stone-700 transition-colors"
                        >
                          {item.ingredient} ({item.strengths[0]})
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 xs:grid-cols-3 gap-2.5">
                  {/* Strength */}
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 uppercase mb-1">
                      Strength
                    </label>
                    <input
                      type="text"
                      value={med.strength}
                      onChange={(e) =>
                        onUpdateMedicine(idx, { ...med, strength: e.target.value })
                      }
                      placeholder="e.g. 20mg, 500mg"
                      className="w-full px-3 py-2 text-sm rounded-xl border border-stone-300 focus:border-emerald-700 outline-none bg-white min-h-[40px]"
                    />
                  </div>

                  {/* Doses per day */}
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 uppercase mb-1">
                      Doses/Day
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="12"
                      value={med.doses_per_day}
                      onChange={(e) =>
                        onUpdateMedicine(idx, {
                          ...med,
                          doses_per_day: Math.max(1, Number(e.target.value) || 1),
                        })
                      }
                      className="w-full px-3 py-2 text-sm rounded-xl border border-stone-300 focus:border-emerald-700 outline-none bg-white tabular-nums min-h-[40px]"
                    />
                  </div>

                  {/* Duration */}
                  <div className="col-span-2 xs:col-span-1">
                    <label className="block text-[11px] font-semibold text-stone-700 uppercase mb-1">
                      Duration (Days)
                    </label>
                    <input
                      type="number"
                      min="1"
                      placeholder="30 (Ongoing)"
                      value={med.duration_days ?? ''}
                      onChange={(e) => {
                        const val = e.target.value.trim();
                        onUpdateMedicine(idx, {
                          ...med,
                          duration_days: val === '' ? null : Math.max(1, Number(val)),
                        });
                      }}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-stone-300 focus:border-emerald-700 outline-none bg-white tabular-nums min-h-[40px]"
                      title="Leave blank for ongoing monthly supply"
                    />
                  </div>
                </div>
              </div>
            );
          })}

          {/* Action Row: Add another & Reset */}
          <div className="flex items-center justify-between gap-2 pt-2 flex-wrap">
            <button
              type="button"
              onClick={onAddMedicine}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors min-h-[44px]"
            >
              <Plus className="w-4 h-4" />
              <span>Add Another Medicine</span>
            </button>

            <button
              type="button"
              onClick={onReset}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-stone-500 hover:text-stone-800 transition-colors min-h-[44px]"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Discard & Re-Scan</span>
            </button>
          </div>

          {/* Primary Confirmation & Calculation CTA */}
          <div className="pt-3 border-t border-stone-100">
            <button
              type="button"
              disabled={isCalculating || medicines.length === 0}
              onClick={onConfirmAndCalculate}
              className="w-full py-4 px-5 bg-emerald-800 hover:bg-emerald-900 active:scale-[0.99] disabled:opacity-50 text-white font-bold text-base rounded-2xl shadow-sm transition-all flex items-center justify-center gap-2 min-h-[48px]"
            >
              {isCalculating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Matching Prices & Preparing Summary...</span>
                </>
              ) : (
                <>
                  <span>Confirm Details & Calculate Costs</span>
                  <ArrowRight className="w-5 h-5 text-emerald-200" />
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
