import React, { useState } from 'react';
import { X, Search, Database, ExternalLink } from 'lucide-react';
import { PRICE_DATABASE, MedicinePriceEntry } from '../data/priceDatabase';

interface PriceCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMedicine?: (entry: MedicinePriceEntry) => void;
}

export const PriceCatalogModal: React.FC<PriceCatalogModalProps> = ({
  isOpen,
  onClose,
  onSelectMedicine,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const filtered = PRICE_DATABASE.filter((entry) => {
    const q = searchTerm.toLowerCase();
    return (
      entry.brand_name.toLowerCase().includes(q) ||
      entry.active_ingredient.toLowerCase().includes(q) ||
      entry.strength.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-stone-100 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-900">
                Illustrative Price Reference Database
              </h3>
              <p className="text-xs text-stone-500">
                {PRICE_DATABASE.length} reference records · Source: "ILLUSTRATIVE DEMO VALUE"
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 rounded-xl min-h-[44px] min-w-[44px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-4 border-b border-stone-100 bg-stone-50/50">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Filter by brand or ingredient (e.g. metformin, lipitor, amlodipine)..."
              className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-stone-200 focus:border-emerald-700 outline-none bg-white"
            />
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-y-auto p-4 space-y-2 flex-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-stone-500 text-sm">
              No matching medicines found in catalog.
            </div>
          ) : (
            filtered.map((entry, idx) => {
              const unitPrice = entry.price / entry.pack_size;
              return (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl border border-stone-200/90 hover:border-emerald-300 hover:bg-emerald-50/20 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-sm"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <strong className="text-stone-900 font-bold">
                        {entry.brand_name}
                      </strong>
                      <span className="text-xs bg-stone-100 px-2 py-0.5 rounded-md font-semibold text-stone-700">
                        {entry.strength}
                      </span>
                    </div>
                    <div className="text-xs text-stone-500">
                      Generic Active:{' '}
                      <span className="font-mono text-emerald-800 font-medium">
                        {entry.active_ingredient}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                    <div className="text-right">
                      <div className="font-bold text-stone-900 tabular-nums">
                        ${entry.price.toFixed(2)}{' '}
                        <span className="text-xs font-normal text-stone-500">
                          ({entry.pack_size}ct)
                        </span>
                      </div>
                      <div className="text-[11px] text-stone-500 tabular-nums">
                        ~${unitPrice.toFixed(2)}/pill
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-semibold text-amber-800 bg-amber-50 px-2 py-1 rounded-md border border-amber-200/80 block">
                        {entry.source}
                      </span>
                    </div>

                    {onSelectMedicine && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectMedicine(entry);
                          onClose();
                        }}
                        className="px-2.5 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 rounded-lg transition-colors whitespace-nowrap min-h-[36px]"
                      >
                        Use in test
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-stone-50 border-t border-stone-100 text-xs text-stone-500 flex items-center justify-between">
          <span>Editable file: <code>src/data/priceDatabase.ts</code></span>
          <span className="font-semibold text-emerald-900">All prices in USD</span>
        </div>
      </div>
    </div>
  );
};
