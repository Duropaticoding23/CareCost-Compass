import React from 'react';
import { AlertTriangle, CheckCircle2, TrendingDown, DollarSign } from 'lucide-react';
import { OverallPrescriptionAnalysis } from '../utils/pricingEngine';

interface BurdenOverviewProps {
  analysis: OverallPrescriptionAnalysis;
  onIncomeChange: (val: number) => void;
}

export const BurdenOverview: React.FC<BurdenOverviewProps> = ({
  analysis,
  onIncomeChange,
}) => {
  const {
    totalCurrentCost,
    totalLowestCost,
    totalPossibleSavings,
    householdIncome,
    incomeBurdenPercent,
    isHighBurden,
    reducedBurdenPercentWithSavings,
  } = analysis;

  return (
    <div className="bg-white rounded-3xl p-4 sm:p-6 md:p-7 shadow-xs border border-emerald-950/10 mb-8 space-y-5 overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-emerald-950 tracking-tight">
            Financial Impact & Income Burden
          </h2>
          <p className="text-xs sm:text-sm text-stone-600">
            Calculated in deterministic code against bioequivalent generic catalog prices.
          </p>
        </div>

        {/* Quick income editor */}
        <div className="flex items-center gap-2 bg-stone-50 border border-stone-200 rounded-2xl px-3 py-1.5 self-start sm:self-auto">
          <DollarSign className="w-4 h-4 text-emerald-800 shrink-0" />
          <span className="text-xs font-semibold text-stone-600">Income:</span>
          <input
            type="number"
            min="0"
            step="50"
            value={householdIncome > 0 ? householdIncome : ''}
            onChange={(e) => onIncomeChange(Number(e.target.value) || 0)}
            placeholder="Set income"
            className="w-24 text-sm font-semibold text-emerald-950 bg-transparent outline-none tabular-nums"
            title="Monthly household income"
          />
          <span className="text-xs text-stone-400">/mo</span>
        </div>
      </div>

      {/* 3 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4">
        {/* Metric 1: Current Estimated Cost */}
        <div className="p-4 md:p-5 rounded-2xl bg-stone-50 border border-stone-200/90 text-center flex flex-col justify-between">
          <span className="text-xs uppercase tracking-wider font-semibold text-stone-500 mb-1">
            Current Brand / Script
          </span>
          <div className="text-2xl md:text-3xl font-extrabold text-stone-900 tabular-nums my-1">
            ${totalCurrentCost.toFixed(2)}
          </div>
          <span className="text-xs text-stone-500">
            Out-of-pocket estimated cost
          </span>
        </div>

        {/* Metric 2: Lowest-Priced Option */}
        <div className="p-4 md:p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-center flex flex-col justify-between">
          <span className="text-xs uppercase tracking-wider font-semibold text-emerald-800 mb-1">
            With Lowest Generic
          </span>
          <div className="text-2xl md:text-3xl font-extrabold text-emerald-900 tabular-nums my-1">
            ${totalLowestCost.toFixed(2)}
          </div>
          <span className="text-xs text-emerald-700">
            Identical active ingredient & dose
          </span>
        </div>

        {/* Metric 3: Possible Savings */}
        <div className="p-4 md:p-5 rounded-2xl bg-emerald-800 text-white text-center flex flex-col justify-between shadow-xs">
          <span className="text-xs uppercase tracking-wider font-semibold text-emerald-200 mb-1 flex items-center justify-center gap-1">
            <TrendingDown className="w-3.5 h-3.5" />
            Potential Family Savings
          </span>
          <div className="text-2xl md:text-3xl font-extrabold text-white tabular-nums my-1">
            ${totalPossibleSavings.toFixed(2)}
          </div>
          <span className="text-xs text-emerald-100">
            {totalCurrentCost > 0
              ? `${Math.round((totalPossibleSavings / totalCurrentCost) * 100)}% cost reduction`
              : 'Zero out-of-pocket delta'}
          </span>
        </div>
      </div>

      {/* Household Income Burden Alert Banner (Highlighting >10% threshold) */}
      {householdIncome > 0 && incomeBurdenPercent !== null ? (
        <div
          className={`p-4 md:p-5 rounded-2xl border transition-all ${
            isHighBurden
              ? 'bg-amber-50 border-amber-300 text-amber-950'
              : 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
          }`}
        >
          <div className="flex items-start gap-3">
            <div
              className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                isHighBurden
                  ? 'bg-amber-200 text-amber-900'
                  : 'bg-emerald-200 text-emerald-900'
              }`}
            >
              {isHighBurden ? (
                <AlertTriangle className="w-5 h-5 text-amber-900" />
              ) : (
                <CheckCircle2 className="w-5 h-5 text-emerald-900" />
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-base font-bold">
                  {isHighBurden
                    ? '⚠️ High Financial Burden (>10% of Income)'
                    : '✓ Moderate Income Burden'}
                </span>
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-bold tabular-nums ${
                    isHighBurden
                      ? 'bg-amber-200 text-amber-950'
                      : 'bg-emerald-200 text-emerald-950'
                  }`}
                >
                  {incomeBurdenPercent}% of monthly income
                </span>
              </div>

              <p className="text-sm leading-relaxed">
                {isHighBurden ? (
                  <>
                    This prescription consumes{' '}
                    <strong className="font-semibold">{incomeBurdenPercent}%</strong> of your{' '}
                    ${householdIncome.toLocaleString()} monthly income, exceeding the standard{' '}
                    <strong className="font-semibold">10% threshold</strong> for catastrophic healthcare expenditure.
                    {reducedBurdenPercentWithSavings !== null && (
                      <>
                        {' '}Switching to bioequivalent generics could lower your medication burden to{' '}
                        <strong className="text-emerald-900 font-bold">
                          {reducedBurdenPercentWithSavings}%
                        </strong>.
                      </>
                    )}
                  </>
                ) : (
                  <>
                    Prescription costs represent{' '}
                    <strong className="font-semibold">{incomeBurdenPercent}%</strong> of your monthly income (well within the safe 10% threshold).
                  </>
                )}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4 bg-stone-50 border border-stone-200 rounded-2xl flex items-center justify-between gap-4 text-xs md:text-sm text-stone-600">
          <span>Enter your monthly household income above to evaluate your 10% catastrophic burden status.</span>
          <button
            type="button"
            onClick={() => onIncomeChange(2000)}
            className="text-emerald-800 font-semibold underline whitespace-nowrap hover:text-emerald-950 min-h-[44px] flex items-center"
          >
            Use Example $2,000/mo
          </button>
        </div>
      )}
    </div>
  );
};
