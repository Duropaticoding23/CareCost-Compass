import React from 'react';
import { Pill, ArrowRight, Check, AlertCircle, Edit2, Trash2, Info } from 'lucide-react';
import { MatchedMedicineResult } from '../utils/pricingEngine';

interface MedicineCardProps {
  item: MatchedMedicineResult;
  onEdit?: (item: MatchedMedicineResult) => void;
  onDelete?: (id: string) => void;
}

export const MedicineCard: React.FC<MedicineCardProps> = ({
  item,
  onEdit,
  onDelete,
}) => {
  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 border border-emerald-900/10 shadow-xs hover:border-emerald-300 transition-colors">
      <div className="flex items-start justify-between gap-2.5 mb-2.5">
        <div className="flex items-start gap-2.5 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
            <Pill className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="text-base font-bold text-stone-900 truncate">
                {item.brand || 'Prescription Drug'}
              </h3>
              <span className="text-xs font-semibold px-2 py-0.5 bg-stone-100 text-stone-700 rounded-md shrink-0">
                {item.strength}
              </span>
            </div>
            <div className="text-xs text-stone-500 mt-0.5 truncate">
              Active: <span className="font-mono font-medium text-emerald-900">{item.active_ingredient}</span>
            </div>
          </div>
        </div>

        {/* Edit/Delete controls */}
        {(onEdit || onDelete) && (
          <div className="flex items-center gap-1 shrink-0">
            {onEdit && (
              <button
                type="button"
                onClick={() => onEdit(item)}
                className="p-2 text-stone-400 hover:text-emerald-800 hover:bg-emerald-50 rounded-xl transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
                title="Edit medicine details"
              >
                <Edit2 className="w-4 h-4" />
              </button>
            )}
            {onDelete && (
              <button
                type="button"
                onClick={() => onDelete(item.id)}
                className="p-2 text-stone-400 hover:text-rose-700 hover:bg-rose-50 rounded-xl transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
                title="Remove medicine"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Regimen and Units */}
      <div className="text-[11px] sm:text-xs text-stone-600 mb-3 flex items-center gap-2 flex-wrap bg-stone-50 p-2.5 rounded-xl">
        <span>
          <strong>{item.doses_per_day}</strong> dose{item.doses_per_day > 1 ? 's' : ''}/day
        </span>
        <span aria-hidden="true" className="text-stone-300">·</span>
        <span>
          {item.duration_days
            ? `${item.duration_days}-day course (${item.totalUnitsNeeded} units)`
            : `30-day supply (${item.totalUnitsNeeded} units/mo)`}
        </span>
        <span aria-hidden="true" className="text-stone-300">·</span>
        <span className="text-stone-500">
          {item.duration_days ? 'Acute short-term' : 'Chronic ongoing'}
        </span>
      </div>

      {/* Requirement 2: Assumption notice when brand is not found in table */}
      {item.assumedHigherPrice && item.assumptionMessage && (
        <div className="mb-3 p-3 rounded-xl bg-amber-50/90 border border-amber-200/90 text-amber-950 text-xs flex items-start gap-2">
          <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong className="font-semibold block text-amber-900">Pricing Assumption:</strong>
            {item.assumptionMessage}
          </div>
        </div>
      )}

      {/* Pricing Comparison */}
      {item.matched ? (
        <div className="space-y-2.5">
          <div className="grid grid-cols-1 xs:grid-cols-2 gap-2.5 text-sm">
            {/* Current Product */}
            <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80">
              <span className="text-[10px] uppercase tracking-wide font-semibold text-stone-500 block mb-0.5 truncate">
                Current ({item.currentProductMatched})
              </span>
              <div className="text-base sm:text-lg font-bold text-stone-900 tabular-nums">
                ${item.currentTotalCost.toFixed(2)}
                <span className="text-xs font-normal text-stone-500">
                  {item.duration_days ? ' /course' : ' /mo'}
                </span>
              </div>
              <div className="text-[11px] text-stone-500 mt-0.5">
                ${item.annualCurrentCost.toFixed(2)}/year (~${item.currentUnitPrice?.toFixed(2)}/pill)
              </div>
            </div>

            {/* Lowest Generic Alternative */}
            <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
              <span className="text-[10px] uppercase tracking-wide font-semibold text-emerald-800 block mb-0.5 truncate">
                Lowest Generic ({item.lowestProductMatched})
              </span>
              <div className="text-base sm:text-lg font-bold text-emerald-900 tabular-nums">
                ${item.lowestTotalCost.toFixed(2)}
                <span className="text-xs font-normal text-emerald-700">
                  {item.duration_days ? ' /course' : ' /mo'}
                </span>
              </div>
              <div className="text-[11px] text-emerald-700 mt-0.5">
                ${item.annualLowestCost.toFixed(2)}/year (~${item.lowestUnitPrice?.toFixed(2)}/pill)
              </div>
            </div>
          </div>

          {/* Savings Callout */}
          {item.possibleSavings > 0 ? (
            <div className="p-2.5 bg-emerald-100/60 border border-emerald-200 rounded-xl flex items-center justify-between text-xs sm:text-sm font-semibold text-emerald-950 flex-wrap gap-1">
              <span className="flex items-center gap-1.5">
                <ArrowRight className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                Generic savings:
              </span>
              <span className="text-emerald-900 font-bold tabular-nums">
                Save ${item.possibleSavings.toFixed(2)}/mo (${item.annualPossibleSavings.toFixed(2)}/yr)
              </span>
            </div>
          ) : (
            <div className="p-2 bg-stone-50 border border-stone-200/70 rounded-xl flex items-center gap-1.5 text-[11px] text-stone-600">
              <Check className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span>Referencing the lowest-priced equivalent option in catalog.</span>
            </div>
          )}
        </div>
      ) : (
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="flex-1">
            <strong>Not in illustrative price table:</strong> {item.errorMessage}
            <div className="mt-0.5 text-stone-600 text-[11px]">
              Ask your pharmacist for a quote and FDA-approved bioequivalent generic options.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
