import React from 'react';
import { Compass, BookOpen, RotateCcw } from 'lucide-react';

interface HeaderProps {
  onOpenCatalog: () => void;
  onReset: () => void;
  hasActivePrescription: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCatalog,
  onReset,
  hasActivePrescription,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#f5f8f5]/90 backdrop-blur-md border-b border-emerald-900/10 mb-4 sm:mb-6">
      <div className="max-w-5xl mx-auto px-3 sm:px-4 py-3 flex items-center justify-between gap-2">
        {/* Zone 1: Single text wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-emerald-800 text-white flex items-center justify-center shadow-xs">
            <Compass className="w-5 h-5 text-emerald-200" />
          </div>
          <div>
            <h1 className="text-lg md:text-xl font-bold tracking-tight text-emerald-950 leading-tight">
              CareCost Compass
            </h1>
            <p className="text-[11px] text-stone-500 hidden sm:block">
              Prescription cost transparency & generic savings
            </p>
          </div>
        </div>

        {/* Zone 2 & 3: Clean single-line functional actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenCatalog}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs md:text-sm font-medium text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-xl transition-colors whitespace-nowrap min-h-[44px]"
            title="Inspect price database catalog"
          >
            <BookOpen className="w-4 h-4 text-emerald-700" />
            <span className="hidden xs:inline">Price Catalog</span>
            <span className="xs:hidden">Catalog</span>
          </button>

          {hasActivePrescription && (
            <button
              type="button"
              onClick={onReset}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs md:text-sm font-medium text-stone-700 hover:text-stone-900 hover:bg-stone-100 border border-stone-200 rounded-xl transition-colors whitespace-nowrap min-h-[44px]"
              title="Clear prescription and start over"
            >
              <RotateCcw className="w-3.5 h-3.5 text-stone-500" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
