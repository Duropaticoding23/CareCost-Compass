import React, { useState, useEffect } from 'react';
import { X, Check } from 'lucide-react';
import { ExtractedMedicine } from '../utils/pricingEngine';

interface MedicineEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (med: ExtractedMedicine) => void;
  initialMedicine: ExtractedMedicine | null;
}

export const MedicineEditorModal: React.FC<MedicineEditorModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialMedicine,
}) => {
  const [brand, setBrand] = useState('');
  const [activeIngredient, setActiveIngredient] = useState('');
  const [strength, setStrength] = useState('');
  const [dosesPerDay, setDosesPerDay] = useState(1);
  const [durationDays, setDurationDays] = useState<number | ''>('');
  const [isOngoing, setIsOngoing] = useState(true);

  useEffect(() => {
    if (initialMedicine) {
      setBrand(initialMedicine.brand || '');
      setActiveIngredient(initialMedicine.active_ingredient || '');
      setStrength(initialMedicine.strength || '');
      setDosesPerDay(initialMedicine.doses_per_day || 1);
      if (initialMedicine.duration_days) {
        setDurationDays(initialMedicine.duration_days);
        setIsOngoing(false);
      } else {
        setDurationDays('');
        setIsOngoing(true);
      }
    } else {
      setBrand('');
      setActiveIngredient('');
      setStrength('');
      setDosesPerDay(1);
      setDurationDays('');
      setIsOngoing(true);
    }
  }, [initialMedicine, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: initialMedicine?.id,
      brand: brand.trim() || activeIngredient.trim(),
      active_ingredient: activeIngredient.toLowerCase().trim(),
      strength: strength.trim(),
      doses_per_day: Math.max(1, Number(dosesPerDay) || 1),
      duration_days: isOngoing || !durationDays ? null : Number(durationDays),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-stone-100">
          <h3 className="text-lg font-bold text-stone-900">
            {initialMedicine ? 'Edit Medication' : 'Add Medication'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 rounded-xl min-h-[44px] min-w-[44px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div>
            <label className="block text-xs font-semibold text-stone-700 uppercase mb-1">
              Brand / Trade Name
            </label>
            <input
              type="text"
              required
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="e.g. Lipitor, Glucophage, Norvasc"
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-emerald-700 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 uppercase mb-1">
              Active Ingredient (Generic Name)
            </label>
            <input
              type="text"
              required
              value={activeIngredient}
              onChange={(e) => setActiveIngredient(e.target.value)}
              placeholder="e.g. atorvastatin, metformin, amlodipine"
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-emerald-700 outline-none font-mono"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase mb-1">
                Strength
              </label>
              <input
                type="text"
                required
                value={strength}
                onChange={(e) => setStrength(e.target.value)}
                placeholder="e.g. 20mg, 500mg"
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-emerald-700 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase mb-1">
                Doses Per Day
              </label>
              <input
                type="number"
                min="1"
                max="10"
                required
                value={dosesPerDay}
                onChange={(e) => setDosesPerDay(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-emerald-700 outline-none tabular-nums"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 uppercase mb-1.5">
              Duration Type
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setIsOngoing(true);
                  setDurationDays('');
                }}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-xl border transition-colors min-h-[44px] ${
                  isOngoing
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                Ongoing (30-day supply)
              </button>
              <button
                type="button"
                onClick={() => setIsOngoing(false)}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-xl border transition-colors min-h-[44px] ${
                  !isOngoing
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                Course Duration (Days)
              </button>
            </div>
          </div>

          {!isOngoing && (
            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase mb-1">
                Course Length (Days)
              </label>
              <input
                type="number"
                min="1"
                max="365"
                value={durationDays}
                onChange={(e) => setDurationDays(Number(e.target.value) || '')}
                placeholder="e.g. 7 or 14"
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-emerald-700 outline-none tabular-nums"
              />
            </div>
          )}

          <div className="pt-3 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-xl border border-stone-200 text-stone-700 font-semibold text-sm hover:bg-stone-50 transition-colors min-h-[44px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-sm transition-colors flex items-center justify-center gap-1.5 min-h-[44px]"
            >
              <Check className="w-4 h-4" />
              <span>Save Medication</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
