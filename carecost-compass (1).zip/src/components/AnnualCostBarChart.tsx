import React, { useState } from 'react';
import { BarChart3, TrendingDown, Calendar, Clock } from 'lucide-react';
import { OverallPrescriptionAnalysis } from '../utils/pricingEngine';

interface AnnualCostBarChartProps {
  analysis: OverallPrescriptionAnalysis;
}

export const AnnualCostBarChart: React.FC<AnnualCostBarChartProps> = ({ analysis }) => {
  const [timeframe, setTimeframe] = useState<'annual' | 'monthly'>('annual');

  const {
    totalCurrentCost,
    totalLowestCost,
    totalPossibleSavings,
    totalAnnualCurrentCost,
    totalAnnualLowestCost,
    totalAnnualSavings,
  } = analysis;

  const isAnnual = timeframe === 'annual';
  const currentCost = isAnnual ? totalAnnualCurrentCost : totalCurrentCost;
  const lowestCost = isAnnual ? totalAnnualLowestCost : totalLowestCost;
  const savings = isAnnual ? totalAnnualSavings : totalPossibleSavings;

  const maxVal = Math.max(currentCost, lowestCost, 1);
  const currentPct = Math.round((currentCost / maxVal) * 100);
  const lowestPct = Math.max(8, Math.round((lowestCost / maxVal) * 100));
  const savingsPct = currentCost > 0 ? Math.round((savings / currentCost) * 100) : 0;

  return (
    <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-xs border border-emerald-950/10 mb-8 overflow-hidden">
      {/* Header with 360px-friendly flex wrap */}
      <div className="flex flex-col xs:flex-row xs:items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h3 className="text-base sm:text-lg font-bold text-emerald-950 tracking-tight truncate">
              {isAnnual ? 'Annual Cost Comparison' : '30-Day Cost Comparison'}
            </h3>
            <p className="text-xs text-stone-500 truncate">
              {isAnnual ? '12-month projection for current vs generics' : 'Single monthly prescription cycle'}
            </p>
          </div>
        </div>

        {/* Timeframe Toggle Buttons (Accessible 44px touch targets) */}
        <div className="flex p-1 bg-stone-100 rounded-xl self-start xs:self-auto shrink-0">
          <button
            type="button"
            onClick={() => setTimeframe('annual')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 min-h-[36px] ${
              isAnnual
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>1 Year</span>
          </button>
          <button
            type="button"
            onClick={() => setTimeframe('monthly')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 min-h-[36px] ${
              !isAnnual
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>30 Days</span>
          </button>
        </div>
      </div>

      {/* Visual Bar Chart */}
      <div className="space-y-4 pt-1">
        {/* Bar 1: Current Prescriptions */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs sm:text-sm font-semibold text-stone-700">
            <span className="flex items-center gap-1.5 truncate">
              <span className="w-2.5 h-2.5 rounded-full bg-stone-400 shrink-0" />
              <span className="truncate">Current Prescriptions</span>
            </span>
            <span className="font-mono font-bold text-stone-900 tabular-nums shrink-0 ml-2">
              ${currentCost.toFixed(2)}
              <span className="text-[11px] font-normal text-stone-500">/{isAnnual ? 'yr' : 'mo'}</span>
            </span>
          </div>
          <div className="w-full h-8 bg-stone-100 rounded-xl overflow-hidden p-1 flex items-center">
            <div
              style={{ width: `${currentPct}%` }}
              className="h-full bg-stone-400 hover:bg-stone-500 transition-all duration-500 rounded-lg flex items-center justify-end px-2"
            >
              <span className="text-[11px] font-bold text-white tabular-nums hidden sm:inline">
                ${currentCost.toFixed(0)}
              </span>
            </div>
          </div>
        </div>

        {/* Bar 2: Lowest-Priced Generic Alternatives */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs sm:text-sm font-semibold text-emerald-900">
            <span className="flex items-center gap-1.5 truncate">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 shrink-0" />
              <span className="truncate">Lowest-Priced Generics</span>
            </span>
            <span className="font-mono font-bold text-emerald-800 tabular-nums shrink-0 ml-2">
              ${lowestCost.toFixed(2)}
              <span className="text-[11px] font-normal text-emerald-600">/{isAnnual ? 'yr' : 'mo'}</span>
            </span>
          </div>
          <div className="w-full h-8 bg-stone-100 rounded-xl overflow-hidden p-1 flex items-center">
            <div
              style={{ width: `${lowestPct}%` }}
              className="h-full bg-emerald-700 hover:bg-emerald-800 transition-all duration-500 rounded-lg flex items-center justify-end px-2 shadow-xs"
            >
              <span className="text-[11px] font-bold text-white tabular-nums hidden sm:inline">
                ${lowestCost.toFixed(0)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Savings Highlight Box */}
      {savings > 0 ? (
        <div className="mt-5 p-3.5 sm:p-4 rounded-2xl bg-emerald-50 border border-emerald-200/90 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 text-white flex items-center justify-center shrink-0">
              <TrendingDown className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs uppercase font-bold text-emerald-800 block">
                {isAnnual ? 'Projected Annual Savings' : 'Monthly Savings'}
              </span>
              <span className="text-xs text-stone-600">
                Identical active ingredients & strengths
              </span>
            </div>
          </div>

          <div className="text-right ml-auto">
            <div className="text-lg sm:text-xl font-extrabold text-emerald-900 font-mono tabular-nums">
              Save ${savings.toFixed(2)}
              <span className="text-xs font-semibold text-stone-500">/{isAnnual ? 'yr' : 'mo'}</span>
            </div>
            <div className="text-[11px] font-semibold text-emerald-700">
              {savingsPct}% total cost reduction
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-4 p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-600 text-center">
          ✓ Your selected items are already referencing the lowest available generic prices in our catalog.
        </div>
      )}
    </div>
  );
};
