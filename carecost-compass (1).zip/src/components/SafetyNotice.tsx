import React from 'react';
import { ShieldAlert, Lock } from 'lucide-react';

export const SafetyNotice: React.FC = () => {
  return (
    <div className="space-y-2 mb-6">
      {/* Mandatory Clinical Safety Guardrail */}
      <div 
        role="alert" 
        className="bg-emerald-50/90 border border-emerald-300/80 rounded-2xl p-4 text-emerald-950 flex items-start gap-3.5 shadow-xs"
      >
        <div className="p-2 bg-emerald-100 rounded-xl text-emerald-800 shrink-0 mt-0.5">
          <ShieldAlert className="w-5 h-5" />
        </div>
        <div className="text-sm leading-relaxed">
          <strong className="font-semibold block text-emerald-900 text-[15px]">
            Mandatory Patient Safety Notice
          </strong>
          Never adjust your dosage, discontinue, or switch medications without professional guidance. A licensed pharmacist or doctor must confirm any bioequivalent generic substitution or treatment adjustment.
        </div>
      </div>

      {/* Privacy Notice */}
      <div className="flex items-center gap-2 text-xs text-stone-600 px-2">
        <Lock className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
        <span>Privacy guarantee: Uploaded prescription images are processed in-memory only and never saved or stored.</span>
      </div>
    </div>
  );
};
