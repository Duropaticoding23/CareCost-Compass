/**
 * CareCost Compass - Price Catalog
 * Separate, easy-to-edit reference database for prescription pricing and generic equivalence.
 * All prices are explicitly marked with the source "ILLUSTRATIVE DEMO VALUE".
 */

export interface MedicinePriceEntry {
  brand_name: string;
  active_ingredient: string; // Generic name in lowercase
  strength: string; // e.g. "500mg", "20mg"
  pack_size: number; // e.g. 30, 60
  price: number; // Price per pack
  currency: string;
  source: string;
}

export const PRICE_DATABASE: MedicinePriceEntry[] = [
  // 1 & 2: Metformin (Type 2 Diabetes)
  {
    brand_name: "Glucophage",
    active_ingredient: "metformin",
    strength: "500mg",
    pack_size: 60,
    price: 34.50,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Metformin HCl Generic",
    active_ingredient: "metformin",
    strength: "500mg",
    pack_size: 60,
    price: 7.80,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 3 & 4: Atorvastatin (Cholesterol / Cardiovascular)
  {
    brand_name: "Lipitor",
    active_ingredient: "atorvastatin",
    strength: "20mg",
    pack_size: 30,
    price: 68.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Atorvastatin Calcium Generic",
    active_ingredient: "atorvastatin",
    strength: "20mg",
    pack_size: 30,
    price: 11.20,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 5 & 6: Amlodipine (Hypertension)
  {
    brand_name: "Norvasc",
    active_ingredient: "amlodipine",
    strength: "5mg",
    pack_size: 30,
    price: 42.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Amlodipine Besylate Generic",
    active_ingredient: "amlodipine",
    strength: "5mg",
    pack_size: 30,
    price: 6.50,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 7 & 8: Omeprazole (Acid Reflux / GERD)
  {
    brand_name: "Prilosec",
    active_ingredient: "omeprazole",
    strength: "20mg",
    pack_size: 28,
    price: 32.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Omeprazole Delayed-Release Generic",
    active_ingredient: "omeprazole",
    strength: "20mg",
    pack_size: 28,
    price: 8.90,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 9 & 10: Losartan (Blood Pressure)
  {
    brand_name: "Cozaar",
    active_ingredient: "losartan",
    strength: "50mg",
    pack_size: 30,
    price: 48.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Losartan Potassium Generic",
    active_ingredient: "losartan",
    strength: "50mg",
    pack_size: 30,
    price: 10.50,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 11 & 12: Sertraline (Depression / Anxiety)
  {
    brand_name: "Zoloft",
    active_ingredient: "sertraline",
    strength: "50mg",
    pack_size: 30,
    price: 58.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Sertraline HCl Generic",
    active_ingredient: "sertraline",
    strength: "50mg",
    pack_size: 30,
    price: 12.40,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 13 & 14: Amoxicillin (Antibiotic)
  {
    brand_name: "Amoxil",
    active_ingredient: "amoxicillin",
    strength: "500mg",
    pack_size: 21,
    price: 22.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Amoxicillin Trihydrate Generic",
    active_ingredient: "amoxicillin",
    strength: "500mg",
    pack_size: 21,
    price: 7.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 15 & 16: Levothyroxine (Thyroid Hormone Deficiency)
  {
    brand_name: "Synthroid",
    active_ingredient: "levothyroxine",
    strength: "50mcg",
    pack_size: 30,
    price: 46.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Levothyroxine Sodium Generic",
    active_ingredient: "levothyroxine",
    strength: "50mcg",
    pack_size: 30,
    price: 13.50,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 17 & 18: Cetirizine (Allergy)
  {
    brand_name: "Zyrtec",
    active_ingredient: "cetirizine",
    strength: "10mg",
    pack_size: 30,
    price: 24.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Cetirizine HCl Generic",
    active_ingredient: "cetirizine",
    strength: "10mg",
    pack_size: 30,
    price: 6.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },

  // 19 & 20: Lisinopril (ACE Inhibitor)
  {
    brand_name: "Zestril",
    active_ingredient: "lisinopril",
    strength: "10mg",
    pack_size: 30,
    price: 36.00,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  },
  {
    brand_name: "Lisinopril Generic",
    active_ingredient: "lisinopril",
    strength: "10mg",
    pack_size: 30,
    price: 5.50,
    currency: "USD",
    source: "ILLUSTRATIVE DEMO VALUE"
  }
];
