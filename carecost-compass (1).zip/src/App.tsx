/**
 * CareCost Compass
 * Prescription cost transparency, 10% income burden analysis, and bioequivalent generic savings.
 */

import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { SafetyNotice } from './components/SafetyNotice';
import { PrescriptionInput } from './components/PrescriptionInput';
import { ExtractedMedicationsReview } from './components/ExtractedMedicationsReview';
import { AnnualCostBarChart } from './components/AnnualCostBarChart';
import { BurdenOverview } from './components/BurdenOverview';
import { MedicineCard } from './components/MedicineCard';
import { PharmacistHelper } from './components/PharmacistHelper';
import { MedicineEditorModal } from './components/MedicineEditorModal';
import { PriceCatalogModal } from './components/PriceCatalogModal';
import {
  ExtractedMedicine,
  calculatePrescriptionAnalysis,
  MatchedMedicineResult,
} from './utils/pricingEngine';
import { Plus, Edit3, RefreshCw, AlertCircle } from 'lucide-react';

type WorkflowStep = 'input' | 'review' | 'results';

export default function App() {
  const [workflowStep, setWorkflowStep] = useState<WorkflowStep>('input');
  const [medicines, setMedicines] = useState<ExtractedMedicine[]>([]);
  const [householdIncome, setHouseholdIncome] = useState<number>(2000);
  const [isLoadingExtract, setIsLoadingExtract] = useState(false);
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  // Gemini consultation summary state
  const [summary, setSummary] = useState<string | null>(null);
  const [questions, setQuestions] = useState<string[]>([]);
  const [safetyNotice, setSafetyNotice] = useState<string | null>(null);

  // Modals
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<ExtractedMedicine | null>(null);

  // Pure deterministic financial calculations in code
  const analysis = useMemo(() => {
    return calculatePrescriptionAnalysis(medicines, householdIncome);
  }, [medicines, householdIncome]);

  // Request consultation summary from Gemini server-side endpoint
  const fetchConsultationSummary = async (
    items: MatchedMedicineResult[],
    currentCost: number,
    savings: number
  ) => {
    if (items.length === 0) return;
    setIsLoadingSummary(true);

    try {
      const response = await fetch('/api/consultation-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          medications: items,
          totalCost: currentCost,
          possibleSavings: savings,
          householdIncome: householdIncome || null,
          burdenPercent: analysis.incomeBurdenPercent || null,
        }),
      });

      if (!response.ok) {
        throw new Error('Could not fetch consultation guide');
      }

      const data = await response.json();
      setSummary(data.summary || null);
      setQuestions(Array.isArray(data.pharmacist_questions) ? data.pharmacist_questions : []);
      setSafetyNotice(data.safety_notice || null);
    } catch (err: any) {
      console.warn('Consultation guide fetch error:', err);
      // Fallback patient reassurance if network or offline
      setSummary(
        'Your prescription includes essential therapies. Bioequivalent generic alternatives provide the identical active ingredient at a lower out-of-pocket cost, though any change must be confirmed with your doctor or pharmacist.'
      );
      setQuestions([
        'Is there an FDA-approved generic equivalent available for my prescription?',
        'Would switching to a 90-day supply reduce my monthly copay or cash price?',
        'Does taking this generic option require any adjustment with food or routine?',
      ]);
    } finally {
      setIsLoadingSummary(false);
    }
  };

  // Step 1 -> Step 2: Handle Photo Extraction
  const handleExtractedFromPhoto = async (base64: string, mimeType: string, incomeVal: number) => {
    setIsLoadingExtract(true);
    setApiError(null);
    if (incomeVal > 0) setHouseholdIncome(incomeVal);

    try {
      const response = await fetch('/api/extract-prescription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to extract medications from prescription photo.');
      }

      if (!data.medicines || data.medicines.length === 0) {
        throw new Error('No medications could be recognized in the image. Please try a clearer photo or type them in.');
      }

      setMedicines(data.medicines);
      // Transition to Step 2: Review & Edit before calculating
      setWorkflowStep('review');
    } catch (err: any) {
      setApiError(err.message || 'Error processing prescription photo.');
    } finally {
      setIsLoadingExtract(false);
    }
  };

  // Step 1 -> Step 2: Handle Text Extraction
  const handleExtractedFromText = async (text: string, incomeVal: number) => {
    setIsLoadingExtract(true);
    setApiError(null);
    if (incomeVal > 0) setHouseholdIncome(incomeVal);

    try {
      const response = await fetch('/api/extract-prescription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to parse prescription text.');
      }

      if (!data.medicines || data.medicines.length === 0) {
        throw new Error('No medicines detected in text. Try entering brand, strength, and doses per day.');
      }

      setMedicines(data.medicines);
      // Transition to Step 2: Review & Edit before calculating
      setWorkflowStep('review');
    } catch (err: any) {
      setApiError(err.message || 'Error processing typed prescription text.');
    } finally {
      setIsLoadingExtract(false);
    }
  };

  // 1-Click Preset loader: Goes to review step so user can inspect and edit
  const handleLoadPreset = (presetItems: ExtractedMedicine[], incomeVal: number) => {
    setApiError(null);
    setHouseholdIncome(incomeVal);
    setMedicines(presetItems);
    setWorkflowStep('review');
  };

  // Step 2 -> Step 3: Confirm details & Calculate
  const handleConfirmAndCalculate = async () => {
    setWorkflowStep('results');
    await fetchConsultationSummary(
      analysis.items,
      analysis.totalCurrentCost,
      analysis.totalPossibleSavings
    );
  };

  // Inline update in review step
  const handleUpdateMedicine = (index: number, updated: ExtractedMedicine) => {
    setMedicines((prev) => {
      const next = [...prev];
      next[index] = updated;
      return next;
    });
  };

  const handleAddMedicineInReview = () => {
    const newMed: ExtractedMedicine = {
      id: `med-${Date.now()}`,
      brand: '',
      active_ingredient: '',
      strength: '',
      doses_per_day: 1,
      duration_days: null,
    };
    setMedicines((prev) => [...prev, newMed]);
  };

  const handleRemoveMedicine = (index: number) => {
    setMedicines((prev) => prev.filter((_, i) => i !== index));
  };

  // Add / Edit / Remove Medicine Handlers for Modal
  const handleSaveMedicine = (savedMed: ExtractedMedicine) => {
    if (savedMed.id && medicines.some((m) => m.id === savedMed.id)) {
      setMedicines((prev) => prev.map((m) => (m.id === savedMed.id ? savedMed : m)));
    } else {
      const newMed = { ...savedMed, id: `med-${Date.now()}` };
      setMedicines((prev) => [...prev, newMed]);
    }
  };

  const handleDeleteMedicine = (id: string) => {
    setMedicines((prev) => prev.filter((m) => m.id !== id));
  };

  const handleResetAll = () => {
    setMedicines([]);
    setSummary(null);
    setQuestions([]);
    setApiError(null);
    setWorkflowStep('input');
  };

  return (
    <div className="min-h-screen bg-[#f5f8f5] text-[#13271c] pb-16 overflow-x-hidden">
      {/* Top Bar Navigation Contract (360px optimized) */}
      <Header
        onOpenCatalog={() => setIsCatalogOpen(true)}
        onReset={handleResetAll}
        hasActivePrescription={medicines.length > 0}
      />

      <main className="max-w-4xl mx-auto px-3 sm:px-4 md:px-6">
        {/* Mandatory Safety Guardrail & In-Memory Privacy Notice */}
        <SafetyNotice />

        {/* Global Error Banner */}
        {apiError && (
          <div className="mb-5 p-3.5 sm:p-4 bg-rose-50 border border-rose-300 rounded-2xl text-rose-900 text-xs sm:text-sm flex items-start gap-2.5 shadow-xs">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <strong className="font-semibold block text-rose-950">Notice:</strong>
              {apiError}
            </div>
            <button
              type="button"
              onClick={() => setApiError(null)}
              className="text-rose-700 hover:text-rose-950 font-bold text-xs p-1 min-h-[36px] flex items-center"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Workflow Step 1: Prescription Input */}
        {workflowStep === 'input' && (
          <PrescriptionInput
            onExtractedFromPhoto={handleExtractedFromPhoto}
            onExtractedFromText={handleExtractedFromText}
            onLoadPreset={handleLoadPreset}
            isLoading={isLoadingExtract}
            income={householdIncome}
            onIncomeChange={setHouseholdIncome}
          />
        )}

        {/* Workflow Step 2: Editable List Before Calculating (Requirement 3) */}
        {workflowStep === 'review' && (
          <ExtractedMedicationsReview
            medicines={medicines}
            onUpdateMedicine={handleUpdateMedicine}
            onAddMedicine={handleAddMedicineInReview}
            onRemoveMedicine={handleRemoveMedicine}
            onConfirmAndCalculate={handleConfirmAndCalculate}
            onReset={handleResetAll}
            isCalculating={isLoadingSummary}
          />
        )}

        {/* Workflow Step 3: Calculated Results & Financial Breakdown */}
        {workflowStep === 'results' && medicines.length > 0 && (
          <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300">
            {/* Action strip to return to Review & Edit */}
            <div className="flex items-center justify-between gap-2 p-3 bg-white rounded-2xl border border-emerald-950/10 shadow-xs flex-wrap">
              <span className="text-xs text-stone-600">
                Calculations based on <strong>{medicines.length} verified medications</strong>.
              </span>
              <button
                type="button"
                onClick={() => setWorkflowStep('review')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-xl transition-colors min-h-[40px]"
              >
                <Edit3 className="w-3.5 h-3.5 text-emerald-700" />
                <span>Edit Medicines List</span>
              </button>
            </div>

            {/* Requirement 4: Bar Chart comparing Current Cost and Lowest-Priced Option for the Year */}
            <AnnualCostBarChart analysis={analysis} />

            {/* Income Burden Overview & 10% Threshold Highlight */}
            <BurdenOverview
              analysis={analysis}
              onIncomeChange={setHouseholdIncome}
            />

            {/* Itemized Medications List with Requirement 2 Brand Assumption Notice */}
            <div className="bg-white rounded-3xl p-4 sm:p-6 md:p-7 shadow-xs border border-emerald-950/10 overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
                <div>
                  <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-emerald-950 tracking-tight">
                    Itemized Medications & Matches ({medicines.length})
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-600">
                    Active ingredients matched against catalog. Missing brands assume higher-priced product.
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingMedicine(null);
                      setIsEditorOpen(true);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200/80 rounded-xl transition-colors min-h-[44px]"
                  >
                    <Plus className="w-4 h-4 text-emerald-700" />
                    <span>Add Item</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      fetchConsultationSummary(
                        analysis.items,
                        analysis.totalCurrentCost,
                        analysis.totalPossibleSavings
                      )
                    }
                    className="p-2 text-stone-500 hover:text-emerald-900 hover:bg-stone-100 rounded-xl transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
                    title="Refresh Pharmacist Consultation Guide"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-3.5">
                {analysis.items.map((item) => (
                  <MedicineCard
                    key={item.id}
                    item={item}
                    onEdit={(med) => {
                      setEditingMedicine(med);
                      setIsEditorOpen(true);
                    }}
                    onDelete={handleDeleteMedicine}
                  />
                ))}
              </div>
            </div>

            {/* Gemini Consultation Helper (Under 120 words + 3 Questions) */}
            <PharmacistHelper
              summary={summary}
              questions={questions}
              safetyNotice={safetyNotice || undefined}
              isLoading={isLoadingSummary}
            />
          </div>
        )}
      </main>

      {/* Manual Medicine Editor Modal */}
      <MedicineEditorModal
        isOpen={isEditorOpen}
        onClose={() => {
          setIsEditorOpen(false);
          setEditingMedicine(null);
        }}
        onSave={handleSaveMedicine}
        initialMedicine={editingMedicine}
      />

      {/* Price Catalog Drawer / Modal */}
      <PriceCatalogModal
        isOpen={isCatalogOpen}
        onClose={() => setIsCatalogOpen(false)}
        onSelectMedicine={(entry) => {
          handleSaveMedicine({
            brand: entry.brand_name,
            active_ingredient: entry.active_ingredient,
            strength: entry.strength,
            doses_per_day: 1,
            duration_days: null,
          });
          if (workflowStep === 'input') {
            setWorkflowStep('review');
          }
        }}
      />
    </div>
  );
}
