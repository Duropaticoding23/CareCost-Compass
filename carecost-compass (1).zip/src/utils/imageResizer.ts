/**
 * Resizes an image to a maximum of 1280 pixels on the longest side.
 * Preserves aspect ratio, reduces memory footprint, and prevents photo upload failures
 * on high-resolution smartphone cameras (12MP - 48MP).
 */

export interface ResizedImageResult {
  base64: string;
  mimeType: string;
  originalWidth: number;
  originalHeight: number;
  width: number;
  height: number;
  sizeKb: number;
  wasResized: boolean;
}

export async function resizeImageToMax1280(file: File): Promise<ResizedImageResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => reject(new Error('Failed to read image file.'));

    reader.onload = () => {
      const img = new Image();

      img.onerror = () => reject(new Error('Failed to decode image data.'));

      img.onload = () => {
        const originalWidth = img.width;
        const originalHeight = img.height;
        const maxDimension = 1280;

        let targetWidth = originalWidth;
        let targetHeight = originalHeight;
        let wasResized = false;

        if (originalWidth > maxDimension || originalHeight > maxDimension) {
          wasResized = true;
          if (originalWidth >= originalHeight) {
            targetWidth = maxDimension;
            targetHeight = Math.round((originalHeight * maxDimension) / originalWidth);
          } else {
            targetHeight = maxDimension;
            targetWidth = Math.round((originalWidth * maxDimension) / originalHeight);
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas 2D context unavailable.'));
          return;
        }

        // Use high-quality image smoothing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

        // Export as JPEG with 0.86 quality for optimal OCR clarity and low file size
        const mimeType = 'image/jpeg';
        const dataUrl = canvas.toDataURL(mimeType, 0.86);
        const base64 = dataUrl.split(',')[1];
        const sizeKb = Math.round((base64.length * 3) / 4 / 1024);

        resolve({
          base64,
          mimeType,
          originalWidth,
          originalHeight,
          width: targetWidth,
          height: targetHeight,
          sizeKb,
          wasResized,
        });
      };

      img.src = reader.result as string;
    };

    reader.readAsDataURL(file);
  });
}
