/**
 * Deterministic pricing and generic equivalence matching engine.
 * Pure code - zero AI hallucinations in financial calculations.
 */

import { PRICE_DATABASE, MedicinePriceEntry } from '../data/priceDatabase';

export interface ExtractedMedicine {
  id?: string;
  brand: string;
  active_ingredient: string; // Generic name in lowercase
  strength: string; // e.g. "500mg"
  doses_per_day: number; // e.g. 1, 2
  duration_days: number | null; // e.g. 7, 14, or null for 30-day ongoing
}

export interface MatchedMedicineResult extends ExtractedMedicine {
  id: string;
  matched: boolean;
  daysCalculated: number;
  totalUnitsNeeded: number;
  currentProductMatched?: string;
  currentUnitPrice?: number;
  currentTotalCost: number;
  lowestProductMatched?: string;
  lowestUnitPrice?: number;
  lowestTotalCost: number;
  possibleSavings: number;
  isAlreadyLowest?: boolean;
  currency: string;
  errorMessage?: string;
  availableOptionsCount?: number;
  // Requirement 2: If brand name is not in table, assume the higher-priced product and tell the user
  assumedHigherPrice?: boolean;
  assumptionMessage?: string;
  // Requirement 4: Annualized cost figures
  annualCurrentCost: number;
  annualLowestCost: number;
  annualPossibleSavings: number;
}

export interface OverallPrescriptionAnalysis {
  items: MatchedMedicineResult[];
  totalCurrentCost: number;
  totalLowestCost: number;
  totalPossibleSavings: number;
  // Annualized totals for 12 months
  totalAnnualCurrentCost: number;
  totalAnnualLowestCost: number;
  totalAnnualSavings: number;
  unmatchedCount: number;
  currency: string;
  householdIncome: number;
  incomeBurdenPercent: number | null;
  isHighBurden: boolean; // > 10%
  reducedBurdenPercentWithSavings: number | null;
}

export function normalizeIngredient(str: string): string {
  if (!str) return '';
  const lower = str.toLowerCase().trim();
  // Strip salt descriptors for broader matching (e.g., "metformin hcl" -> "metformin")
  return lower
    .replace(/\b(hcl|hydrochloride|calcium|sodium|potassium|besylate|trihydrate|succinate|tartrate|fumarate|maleate)\b/gi, '')
    .replace(/[^a-z0-9]/g, '');
}

export function normalizeStrength(str: string): string {
  if (!str) return '';
  return str.toLowerCase().replace(/\s+/g, '').replace(/,/g, '.');
}

export function matchAndCalculateMedicine(
  med: ExtractedMedicine,
  index: number = 0
): MatchedMedicineResult {
  const id = med.id || `med-${index}-${Date.now()}`;
  const daysCalculated = med.duration_days && med.duration_days > 0 ? med.duration_days : 30;
  const dosesPerDay = Math.max(1, med.doses_per_day || 1);
  const totalUnitsNeeded = dosesPerDay * daysCalculated;
  const isOngoing = med.duration_days === null || med.duration_days === undefined;

  const targetIngredient = normalizeIngredient(med.active_ingredient);
  const targetStrength = normalizeStrength(med.strength);

  // Search in PRICE_DATABASE
  const candidateMatches = PRICE_DATABASE.filter(entry => {
    const entryIngredient = normalizeIngredient(entry.active_ingredient);
    const entryStrength = normalizeStrength(entry.strength);
    return entryIngredient === targetIngredient && entryStrength === targetStrength;
  });

  if (candidateMatches.length === 0) {
    return {
      ...med,
      id,
      matched: false,
      daysCalculated,
      totalUnitsNeeded,
      currentTotalCost: 0,
      lowestTotalCost: 0,
      possibleSavings: 0,
      annualCurrentCost: 0,
      annualLowestCost: 0,
      annualPossibleSavings: 0,
      currency: 'USD',
      errorMessage: `No price data available in table for active ingredient "${med.active_ingredient || med.brand}" (${med.strength}).`,
    };
  }

  // Check for brand name match
  const normBrand = (med.brand || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const brandMatch = candidateMatches.find(c => {
    const normEntryBrand = c.brand_name.toLowerCase().replace(/[^a-z0-9]/g, '');
    return normEntryBrand === normBrand || normEntryBrand.includes(normBrand) || normBrand.includes(normEntryBrand);
  });

  let currentEntry: MedicinePriceEntry;
  let assumedHigherPrice = false;
  let assumptionMessage: string | undefined;

  if (brandMatch) {
    // Exact or partial brand match found in table
    currentEntry = brandMatch;
  } else {
    // Requirement 2: "If the brand name is not in the table, assume the higher-priced product and tell the user that assumption."
    // Sort candidates by unit price descending
    const sortedByPriceDesc = [...candidateMatches].sort((a, b) => {
      const unitA = a.price / a.pack_size;
      const unitB = b.price / b.pack_size;
      return unitB - unitA;
    });

    currentEntry = sortedByPriceDesc[0];
    assumedHigherPrice = true;
    const brandLabel = med.brand ? `"${med.brand}"` : 'Your specified brand';
    assumptionMessage = `${brandLabel} was not found in the price table. Assumed the higher-priced option (${currentEntry.brand_name} at $${currentEntry.price.toFixed(2)}) as conservative baseline.`;
  }

  const currentUnitPrice = currentEntry.price / currentEntry.pack_size;
  const currentTotalCost = Number((currentUnitPrice * totalUnitsNeeded).toFixed(2));

  // Find lowest priced candidate
  let lowestEntry = candidateMatches[0];
  let minUnitPrice = lowestEntry.price / lowestEntry.pack_size;

  for (const candidate of candidateMatches) {
    const unitPrice = candidate.price / candidate.pack_size;
    if (unitPrice < minUnitPrice) {
      minUnitPrice = unitPrice;
      lowestEntry = candidate;
    }
  }

  const lowestTotalCost = Number((minUnitPrice * totalUnitsNeeded).toFixed(2));
  const possibleSavings = Math.max(0, Number((currentTotalCost - lowestTotalCost).toFixed(2)));
  const isAlreadyLowest = currentEntry.brand_name === lowestEntry.brand_name || possibleSavings <= 0.05;

  // Requirement 4: Annualized calculations (12 months for ongoing maintenance, or 1 course for acute)
  const annualMultiplier = isOngoing ? 12 : 1;
  const annualCurrentCost = Number((currentTotalCost * annualMultiplier).toFixed(2));
  const annualLowestCost = Number((lowestTotalCost * annualMultiplier).toFixed(2));
  const annualPossibleSavings = Math.max(0, Number((annualCurrentCost - annualLowestCost).toFixed(2)));

  return {
    ...med,
    id,
    matched: true,
    daysCalculated,
    totalUnitsNeeded,
    currentProductMatched: currentEntry.brand_name,
    currentUnitPrice: Number(currentUnitPrice.toFixed(3)),
    currentTotalCost,
    lowestProductMatched: lowestEntry.brand_name,
    lowestUnitPrice: Number(minUnitPrice.toFixed(3)),
    lowestTotalCost,
    possibleSavings,
    isAlreadyLowest,
    currency: currentEntry.currency,
    availableOptionsCount: candidateMatches.length,
    assumedHigherPrice,
    assumptionMessage,
    annualCurrentCost,
    annualLowestCost,
    annualPossibleSavings,
  };
}

export function calculatePrescriptionAnalysis(
  medicines: ExtractedMedicine[],
  householdIncome: number = 0
): OverallPrescriptionAnalysis {
  const items = medicines.map((m, i) => matchAndCalculateMedicine(m, i));

  let totalCurrentCost = 0;
  let totalLowestCost = 0;
  let totalPossibleSavings = 0;
  let totalAnnualCurrentCost = 0;
  let totalAnnualLowestCost = 0;
  let totalAnnualSavings = 0;
  let unmatchedCount = 0;

  for (const item of items) {
    if (item.matched) {
      totalCurrentCost += item.currentTotalCost;
      totalLowestCost += item.lowestTotalCost;
      totalPossibleSavings += item.possibleSavings;
      totalAnnualCurrentCost += item.annualCurrentCost;
      totalAnnualLowestCost += item.annualLowestCost;
      totalAnnualSavings += item.annualPossibleSavings;
    } else {
      unmatchedCount++;
    }
  }

  totalCurrentCost = Number(totalCurrentCost.toFixed(2));
  totalLowestCost = Number(totalLowestCost.toFixed(2));
  totalPossibleSavings = Number(totalPossibleSavings.toFixed(2));
  totalAnnualCurrentCost = Number(totalAnnualCurrentCost.toFixed(2));
  totalAnnualLowestCost = Number(totalAnnualLowestCost.toFixed(2));
  totalAnnualSavings = Number(totalAnnualSavings.toFixed(2));

  let incomeBurdenPercent: number | null = null;
  let isHighBurden = false;
  let reducedBurdenPercentWithSavings: number | null = null;

  if (householdIncome > 0) {
    incomeBurdenPercent = Number(((totalCurrentCost / householdIncome) * 100).toFixed(1));
    isHighBurden = incomeBurdenPercent > 10.0;
    reducedBurdenPercentWithSavings = Number(((totalLowestCost / householdIncome) * 100).toFixed(1));
  }

  return {
    items,
    totalCurrentCost,
    totalLowestCost,
    totalPossibleSavings,
    totalAnnualCurrentCost,
    totalAnnualLowestCost,
    totalAnnualSavings,
    unmatchedCount,
    currency: 'USD',
    householdIncome,
    incomeBurdenPercent,
    isHighBurden,
    reducedBurdenPercentWithSavings,
  };
}
